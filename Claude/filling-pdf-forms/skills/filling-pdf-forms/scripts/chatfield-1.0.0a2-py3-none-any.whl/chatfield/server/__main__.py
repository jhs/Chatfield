"""Enable running the server as: python -m chatfield.server"""

from .cli import main

if __name__ == '__main__':
    main()

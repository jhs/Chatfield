"""Chatfield FastAPI server for conversational data collection."""

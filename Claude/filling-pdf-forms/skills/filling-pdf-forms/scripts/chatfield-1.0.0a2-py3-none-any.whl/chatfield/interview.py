"""Chatfield interview."""

import re
# import json
# import textwrap
import copy
import logging
import traceback
from typing import Type, TypeVar, List, Dict, Any, Callable
from types import SimpleNamespace

from .field_proxy import FieldProxy, create_field_proxy

logger = logging.getLogger(__name__)

T = TypeVar('T', bound='Interview')

# class Interview(BaseModel):
class Interview:
    """Base class for creating Socratic dialogue interfaces.
    
    Inherit from this class to create a dialogue that conducts
    conversations to collect information from users.
    
    Example:
        class TechHelp(Interview):
            def problem(): "What's not working?"
            def tried(): "What have you tried?"
    """


    # At this time, .model_dump() is needed by langgraph's checkpointer serializer.
    # Just explicitly track it. For now it's not defined what happens if the caller
    # defines a field that collides with these names.
    # - Jason Sun Aug 17 03:19:08 PM CDT 2025
    not_field_names = {'model_dump'}

    # _chatfield_roles = {
    #     'alice': {'type': None, 'traits': []},
    #     'bob'  : {'type': None, 'traits': []},
    # }

    # TODO HERE
    # Next step is get a TS build and get Chatfield working in a browser.

    def __init__(self, **kwargs):
        try:
            self.__inner_init__(**kwargs)
        except Exception as er:
            # The LangGraph deserializer will silently catch any Exception and then just return
            # the value of kwargs here. For now at least log out any errors that happen.
            logger.exception(f'Error initializing {self.__class__.__name__}')
            raise er

    def __inner_init__(self, type=None, desc=None, roles=None, fields=None, **kwargs):
        # print(f'{self.__class__.__name__}: Init')
        if kwargs:
            raise Exception(f'Unknown kwargs to {self.__class__.__name__}(): {kwargs}')

        # I hope this is no longer needed.
        # self.__class__._ensure_roles()
        
        if not desc:
            if self.__class__ is not Interview:
                desc = self.__doc__ or self.__class__.__name__

        roles = roles or {
            'alice': {
                'type': 'Agent',
                'traits': []
            },
            'bob': {
                'type': 'User',
                'traits': []
            },
        }

        chatfield_interview = {
            'type': type,
            'desc': desc,
            'roles': roles,
            'fields': fields or {},
        }

        # field_def = {
        #     'desc': attr.__doc__ or attr.__name__,
        #     'specs': attr._chatfield.get('specs', {}),
        #     'casts': attr._chatfield.get('casts', {}),
        #     'value': None,  # This will be set by the LLM.
        # }
        # chatfield_interview['fields'][attr_name] = field_def

        # fields = kwargs.get('fields', {})
        # for field_name, field_value in fields.items():
        #     value = field_value.get('value', None)
        #     if value is None:
        #         # print(f'{self.__class__.__name__} field not yet present: {field_name!r}')
        #         pass
        #     else:
        #         print(f'{self.__class__.__name__} value of field {field_name!r}: {value!r}')
        #         chatfield = chatfield_interview['fields'][field_name]
        #         if chatfield.get('value'):
        #             raise Exception(f'{self.__class__.__name__} field {field_name!r} already has a value: {chatfield["value"]!r}')
        #         else:
        #             print(f'- fine to set value for {field_name!r}')
        #         chatfield['value'] = value
        
        self._chatfield = copy.deepcopy(chatfield_interview)

    @classmethod
    def _init_field(cls, func: Callable):
        if not hasattr(func, '_chatfield'):
            func._chatfield = {
                'specs': {},
                'casts': {},
            }
    
    @classmethod
    def _ensure_roles(cls):
        raise Exception(f'This might be a bug because everything is re-using the Interview class again')
        if not hasattr(cls, '_chatfield_roles'):
            cls._chatfield_roles = {}

        if 'alice' not in cls._chatfield_roles:
            cls._chatfield_roles['alice'] = {
                'type': None,
                'traits': [],
            }
        
        if 'bob' not in cls._chatfield_roles:
            cls._chatfield_roles['bob'] = {
                'type': None,
                'traits': [],
            }

    # This must take kwargs to support langsmith calling it.
    def model_dump(self, **kwargs) -> Dict[str, Any]:
        # print(f'model_dump: kwargs={kwargs!r}')
        result = copy.deepcopy(self._chatfield)
        return result
    
    def _copy_from(self, source):
        """
        Copy from an interview into this object
        """

        # The current implementation is very minimal.
        self._chatfield = copy.deepcopy(source._chatfield)
    
    @property
    def _name(self) -> str:
        """Return a human-readable label representing this interview data type"""
        return self._chatfield['type']
    
    def _id(self) -> str:
        """Return this interview data type as a valid identifier (lowercase, underscores)"""
        name = self._name
        # name = name.lower()
        name = re.sub(r'\s+', '_', name)          # Replace whitespace with underscores
        name = re.sub(r'[^a-zA-Z0-9_]', '', name) # Remove non-alphanumeric/underscore characters
        name = re.sub(r'_+', '_', name)           # Collapse multiple underscores
        name = name.strip('_')                    # Remove leading/trailing underscores
        name = name or 'interview'
        return name
    
    def _get_role_info(self, role_name: str):
        """Get role information as an object with type and traits.

        Args:
            role_name: Either 'alice' or 'bob'

        Returns:
            SimpleNamespace with type and traits properties
        """
        role = self._chatfield.get('roles', {}).get(role_name, {})

        # Get explicit traits
        traits = role.get('traits', [])

        return SimpleNamespace(
            type=role.get('type'),
            traits=list(traits)
        )
    
    @property
    def _alice(self):
        """Return alice role as an object with traits property."""
        return self._get_role_info('alice')
    
    @property
    def _bob(self):
        """Return bob role as an object with traits property."""
        return self._get_role_info('bob')
    
    def _get_oneliner(self, role_name: str):
        """Return a one-line string of all role info, given a role name."""
        role = self._get_role(role_name)
        role_type = role['type']
        traits = role['traits']

        if traits:
            traits_str = ', '.join(traits)
            return f'{role_type} ({traits_str})'
        else:
            return role_type

    @property
    def _alice_oneliner(self):
        return self._get_oneliner('alice')
    
    @property
    def _bob_oneliner(self):
        return self._get_oneliner('bob')
    
    @property
    def _alice_role(self):
        return self._get_role('alice')
    
    @property
    def _bob_role(self):
        return self._get_role('bob')

    @property
    def _alice_role_name(self) -> str:
        return self._get_role_name(f'alice', f'Agent')
    
    @property
    def _bob_role_name(self) -> str:
        return self._get_role_name(f'bob', f'User')
    
    def _get_role_name(self, role_name: str, default: str) -> str:
        role = self._get_role(role_name)
        role_type = role.get('type') or default
        return role_type
    
    def _get_role(self, role_name: str):
        roles = self._chatfield['roles']
        role = roles[role_name]
        # role = roles.get(role_name, {})
        return role
    
    def _get_chat_field(self, field_name: str):
        """Get the chatfield metadata for a field in this interview."""
        try:
            return self._chatfield['fields'][field_name]
        except KeyError:
            logger.error(f'{self._name}: Not a field: {field_name!r}, must be {self._chatfield["fields"].keys()!r}')
            raise KeyError(f'{self._name}: Not a field: {field_name!r}')

    def _fields(self) -> List[str]:
        """Return a list of field names defined in this interview."""
        return self._chatfield['fields'].keys()

    def __getattr__(self, name: str):
        """Get field values or other attributes.
        
        For defined fields, returns either None or a FieldValueProxy.
        Overrides the method access to return field values instead.
        """
        # I'm not sure why this can happen, usually in the thread workers.
        if '_chatfield' not in self.__dict__:
            raise AttributeError(f'{self.__class__.__name__}: No such attribute: {name!r} (no _chatfield yet)')

        self_chatfield = self.__dict__['_chatfield']
        fields = self_chatfield['fields']
        chatfield = fields.get(name, None) # if fields else None
        if chatfield is None:
            raise AttributeError(f'{self.__class__.__name__}: No such attribute: {name!r}')

        # At this point, chatfield is definitely a field.
        llm_value = chatfield['value']
        if llm_value is None:
            # print(f'Return None to represent unpopulated field: {name!r}')
            return None
        
        # print(f'Valid field {name!r}: {llm_value!r}')
        primary_value = llm_value['value']
        proxy = create_field_proxy(primary_value, chatfield)
        return proxy

    def __getitem__(self, name: str):
        """Access fields via bracket notation (supports special characters).

        This method enables bracket notation access for field names containing
        special characters like brackets, dots, spaces, or reserved words.

        Examples:
            interview["field[0]"]
            interview["user.name"]
            interview["full name"]
            interview["class"]
        """
        return self.__getattr__(name)

    def _pretty(self) -> str:
        """Return a pretty representation of this interview."""
        lines = [f'{self._name}']

        for field_name, chatfield in self._chatfield['fields'].items():
            proxy = getattr(self, field_name)
            if proxy is None:
                lines.append(f'  {field_name}: None')
            else:
                # field is a proxy
                # llm_value = chatfield['value']
                lines.append(f'  {field_name}: {proxy!r}')
                pretty = proxy._pretty()
                if pretty:
                    lines.append(pretty)
        return '\n'.join(lines)
    
    @property
    def _done(self):
        """Return whether all fields have been collected.
        
        Returns True when all fields have been populated with values.
        """
        fields = self._chatfield['fields']
        if not fields:
            # Empty interview is considered done
            return True

        chatfields = fields.values()
        all_values = [ chatfield['value'] for chatfield in chatfields ]
        return all(value is not None for value in all_values)
    
    @property
    def _enough(self):
        """Return whether all non-confidential, non-conclude fields have been
        collected, i.e. enough to wrap up the interview.
        
        Returns True when all fields which have confidential and conclude set to False are populated.
        """
        fields = self._chatfield['fields']
        for field_name, chatfield in fields.items():
            specs = chatfield['specs']
            if not specs['confidential']:
                if not specs['conclude']:
                    # This is a "normal" field.
                    if chatfield['value'] is None:
                        return False
        return True


